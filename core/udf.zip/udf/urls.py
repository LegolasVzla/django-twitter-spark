#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from django.conf.urls import url
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
]
