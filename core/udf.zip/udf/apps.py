from django.apps import AppConfig


class UdfConfig(AppConfig):
    name = 'udf'
